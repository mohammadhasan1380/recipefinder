'use client';

import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ChevronDown } from 'lucide-react';

const cuisines = [
  'Italian',
  'Mexican',
  'Chinese',
  'Indian',
  'Japanese',
  'Thai',
  'Mediterranean',
  'American',
  'French',
];

const diets = [
  'Vegetarian',
  'Vegan',
  'Gluten Free',
  'Ketogenic',
  'Paleo',
  'Low FODMAP',
];

export function RecipeFilters() {
  return (
    <div className="flex flex-wrap gap-4 mb-6">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline">
            Cuisine
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          {cuisines.map((cuisine) => (
            <DropdownMenuItem key={cuisine}>{cuisine}</DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline">
            Diet
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          {diets.map((diet) => (
            <DropdownMenuItem key={diet}>{diet}</DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <Button variant="outline">
        Most Popular
        <ChevronDown className="ml-2 h-4 w-4" />
      </Button>
    </div>
  );
}