/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: { 
    unoptimized: true,
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
      },
      {
        protocol: 'https',
        hostname: 'spoonacular.com',
      },
      {
        protocol: 'https',
        hostname: '**.spoonacular.com',
      },
      {
        protocol: 'https',
        hostname: 'cdn.dribbble.com',
      }
    ]
  },
};

module.exports = nextConfig;