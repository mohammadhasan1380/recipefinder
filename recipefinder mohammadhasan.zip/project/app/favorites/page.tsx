'use client';

import { useState, useEffect } from 'react';
import { Clock, Users, Gauge, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { getFavorites, removeFromFavorites, type FavoriteRecipe } from '@/lib/favorites';

export default function Favorites() {
  const [favorites, setFavorites] = useState<FavoriteRecipe[]>([]);

  useEffect(() => {
    setFavorites(getFavorites());
  }, []);

  const handleRemove = (id: number) => {
    removeFromFavorites(id);
    setFavorites(getFavorites());
  };

  return (
    <main className="min-h-[calc(100vh-4rem)] bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">Your Favorite Recipes</h1>
          <p className="text-lg text-muted-foreground">
            {favorites.length > 0
              ? `You have ${favorites.length} favorite ${favorites.length === 1 ? 'recipe' : 'recipes'}`
              : 'Start saving your favorite recipes!'}
          </p>
        </div>

        {favorites.length === 0 ? (
          <div className="text-center py-12">
            <div className="mb-6">
              <div className="size-20 mx-auto bg-muted rounded-full flex items-center justify-center">
                <Heart className="h-10 w-10 text-muted-foreground" />
              </div>
            </div>
            <h2 className="text-2xl font-semibold mb-2">No favorites yet</h2>
            <p className="text-muted-foreground mb-6">
              Explore recipes and save your favorites to find them here later.
            </p>
            <Link href="/">
              <Button>
                Discover Recipes
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map((recipe) => (
              <div key={recipe.id} className="recipe-card group">
                <Link href={`/recipe/${recipe.id}`}>
                  <div className="relative aspect-video rounded-t-xl overflow-hidden">
                    <Image
                      src={recipe.image}
                      alt={recipe.title}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    />
                  </div>
                </Link>
                
                <div className="p-4">
                  <div className="flex items-start justify-between gap-4 mb-4">
                    <Link href={`/recipe/${recipe.id}`}>
                      <h2 className="text-xl font-semibold group-hover:text-primary transition-colors">
                        {recipe.title}
                      </h2>
                    </Link>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => handleRemove(recipe.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{recipe.readyInMinutes}m</span>
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      <span>{recipe.servings}</span>
                    </div>
                    <div className="flex items-center">
                      <Gauge className="h-4 w-4 mr-1" />
                      <span>{recipe.healthScore}%</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}