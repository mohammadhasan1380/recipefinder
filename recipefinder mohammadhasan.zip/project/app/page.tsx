'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Clock, Users, Gauge } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';

const featuredRecipes = [
  {
    id: 716429,
    title: "Pasta with Garlic, Scallions, Cauliflower & Breadcrumbs",
    image: "https://spoonacular.com/recipeImages/716429-556x370.jpg",
    readyInMinutes: 45,
    servings: 2,
    healthScore: 92,
  },
  {
    id: 715538,
    title: "What to make for dinner tonight?? Bruschetta Style Pork & Pasta",
    image: "https://spoonacular.com/recipeImages/715538-556x370.jpg",
    readyInMinutes: 35,
    servings: 4,
    healthScore: 86,
  },
  {
    id: 716437,
    title: "Chilled Cucumber Avocado Soup with Yogurt and Kefir",
    image: "https://spoonacular.com/recipeImages/716437-556x370.jpg",
    readyInMinutes: 45,
    servings: 2,
    healthScore: 94,
  }
];

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setIsSearching(true);
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <main className="min-h-[calc(100vh-4rem)] relative overflow-hidden bg-[#f8f9fa] dark:bg-gray-900">
      <div className="absolute inset-0 bg-gradient-to-b from-[#e9ecef]/50 to-transparent dark:from-gray-800/50" />
      
      <div className="container mx-auto px-4">
        <div className="relative z-10 pt-8 md:pt-12 lg:pt-16">
          <div className="max-w-7xl mx-auto">
            {/* Mobile Hero Section */}
            <div className="lg:hidden text-center mb-8">
              <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[#2f855a] to-[#48bb78]">
                Fresh Ingredients,<br />Delicious Recipes
              </h1>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Discover amazing recipes using the freshest ingredients
              </p>
            </div>

            <div className="relative mb-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                {/* Left Side Content - Hidden on Mobile */}
                <div className="hidden lg:block lg:col-span-3 text-left space-y-6">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-[#6eaa5e]/10 to-[#48bb78]/10 rounded-2xl blur-xl" />
                    <div className="relative bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 dark:border-gray-700">
                      <h2 className="text-2xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[#2f855a] to-[#38a169]">
                        Fresh Ingredients
                      </h2>
                      <p className="text-gray-600 dark:text-gray-300">
                        Discover recipes using the freshest seasonal ingredients from local markets.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Center Image and Search */}
                <div className="lg:col-span-6">
                  <div className="relative w-full h-[300px] md:w-[600px] md:h-[600px] mx-auto">
                    <div className="absolute inset-0 bg-[#6eaa5e]/20 blur-3xl rounded-full animate-pulse" />
                    <Image
                      src="https://cdn.dribbble.com/userupload/28221764/file/original-03fc9cd488d6ceb40b1b5deda19b5a72.gif"
                      alt="Fresh Food Market Animation"
                      fill
                      priority
                      className="relative z-10 object-contain mix-blend-multiply dark:mix-blend-normal"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 600px, 700px"
                      unoptimized
                    />
                  </div>
                    
                  {/* Search Box - Responsive */}
                  <div className="mt-6 lg:mt-0 lg:absolute lg:inset-x-0 lg:bottom-0 z-20 p-4 lg:p-8">
                    <form onSubmit={handleSearch} className="w-full max-w-2xl mx-auto">
                      <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-r from-[#6eaa5e]/20 via-[#48bb78]/20 to-[#6eaa5e]/20 rounded-2xl blur-xl -z-10" />
                        <div className="relative bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border border-gray-200 dark:border-gray-700 rounded-2xl p-3 shadow-lg">
                          <div className="flex flex-col sm:flex-row gap-3">
                            <Input
                              type="text"
                              placeholder="Search recipes..."
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              className="h-14 text-lg bg-white/50 dark:bg-gray-900/50"
                            />
                            <Button 
                              type="submit" 
                              size="lg" 
                              className={`h-14 sm:w-auto w-full px-8 rounded-xl transition-all duration-300 ${
                                isSearching 
                                  ? 'bg-[#38a169] scale-95' 
                                  : 'bg-[#48bb78] hover:bg-[#38a169] hover:scale-105'
                              }`}
                            >
                              <Search className={`mr-2 h-5 w-5 transition-transform ${isSearching ? 'animate-pulse' : ''}`} />
                              {isSearching ? 'Searching...' : 'Search'}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>

                {/* Right Side Content - Hidden on Mobile */}
                <div className="hidden lg:block lg:col-span-3 text-right space-y-6">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-l from-[#6eaa5e]/10 to-[#48bb78]/10 rounded-2xl blur-xl" />
                    <div className="relative bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 dark:border-gray-700">
                      <h2 className="text-2xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[#38a169] to-[#48bb78]">
                        Delicious Recipes
                      </h2>
                      <p className="text-gray-600 dark:text-gray-300">
                        Create memorable meals that bring joy to your kitchen and table.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Categories - Mobile Only */}
            <div className="lg:hidden grid grid-cols-2 gap-4 mb-12">
              <div className="bg-white/90 dark:bg-gray-800/90 p-4 rounded-xl border border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-[#2f855a] mb-2">Quick Meals</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">Ready in 30 minutes or less</p>
              </div>
              <div className="bg-white/90 dark:bg-gray-800/90 p-4 rounded-xl border border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-[#2f855a] mb-2">Healthy Choice</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">Nutritious and delicious</p>
              </div>
            </div>

            <div className="mt-8 lg:mt-16">
              <h2 className="text-3xl font-bold mb-8 text-center text-gray-800 dark:text-gray-100">Featured Recipes</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredRecipes.map((recipe) => (
                  <Link
                    key={recipe.id}
                    href={`/recipe/${recipe.id}`}
                    className="group relative bg-white dark:bg-gray-800 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-[#6eaa5e]/5 to-[#48bb78]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="relative aspect-video rounded-t-xl overflow-hidden">
                      <Image
                        src={recipe.image}
                        alt={recipe.title}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      />
                    </div>
                    
                    <div className="p-4">
                      <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-100 group-hover:text-[#48bb78] transition-colors line-clamp-2">
                        {recipe.title}
                      </h3>
                      
                      <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>{recipe.readyInMinutes}m</span>
                        </div>
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-1" />
                          <span>{recipe.servings}</span>
                        </div>
                        <div className="flex items-center">
                          <Gauge className="h-4 w-4 mr-1" />
                          <span>{recipe.healthScore}%</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}