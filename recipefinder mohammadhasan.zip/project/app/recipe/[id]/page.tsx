'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ChevronLeft, Clock, Users, Gauge, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { addToFavorites, removeFromFavorites, isInFavorites, type FavoriteRecipe } from '@/lib/favorites';

type RecipeDetails = FavoriteRecipe & {
  summary: string;
  instructions: string;
  extendedIngredients: Array<{
    id: number;
    original: string;
  }>;
};

export default function RecipeDetail() {
  const params = useParams();
  const router = useRouter();
  const [recipe, setRecipe] = useState<RecipeDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    const fetchRecipe = async () => {
      if (!params.id) return;
      
      try {
        setLoading(true);
        setError(null);
        const response = await fetch(
          `https://api.spoonacular.com/recipes/${params.id}/information?apiKey=${process.env.NEXT_PUBLIC_SPOONACULAR_API_KEY}`
        );
        
        if (!response.ok) {
          throw new Error('Failed to fetch recipe details');
        }
        
        const data = await response.json();
        setRecipe(data);
        setIsFavorite(isInFavorites(Number(params.id)));
      } catch (err) {
        setError('Failed to load recipe details. Please try again later.');
        console.error('Error fetching recipe:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchRecipe();
  }, [params.id]);

  const toggleFavorite = () => {
    if (!recipe) return;

    const { id, title, image, readyInMinutes, servings, healthScore } = recipe;
    const recipeData: FavoriteRecipe = {
      id,
      title,
      image,
      readyInMinutes,
      servings,
      healthScore,
    };

    if (isFavorite) {
      removeFromFavorites(id);
    } else {
      addToFavorites(recipeData);
    }
    setIsFavorite(!isFavorite);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="relative">
          <div className="size-16 rounded-full border-4 border-primary/20 animate-spin border-t-primary" />
        </div>
      </div>
    );
  }

  if (error || !recipe) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-destructive text-lg mb-4">{error || 'Recipe not found'}</p>
          <Button onClick={() => router.back()}>Go Back</Button>
        </div>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-start justify-between">
          <div>
            <Button variant="ghost" onClick={() => router.back()} className="mb-4">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <h1 className="text-4xl font-bold mb-2">{recipe.title}</h1>
            <div className="flex items-center gap-6 text-muted-foreground">
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                <span>{recipe.readyInMinutes}m</span>
              </div>
              <div className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                <span>{recipe.servings} servings</span>
              </div>
              <div className="flex items-center">
                <Gauge className="h-5 w-5 mr-2" />
                <span>{recipe.healthScore}% health score</span>
              </div>
            </div>
          </div>
          <Button
            variant={isFavorite ? "secondary" : "outline"}
            size="icon"
            className="h-12 w-12"
            onClick={toggleFavorite}
          >
            <Heart className={`h-6 w-6 ${isFavorite ? "fill-current" : ""}`} />
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div className="relative aspect-video rounded-2xl overflow-hidden">
            <Image
              src={recipe.image}
              alt={recipe.title}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
          
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold mb-4">About this Recipe</h2>
              <div
                className="prose prose-neutral dark:prose-invert"
                dangerouslySetInnerHTML={{ __html: recipe.summary }}
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <h2 className="text-2xl font-semibold mb-4">Ingredients</h2>
            <ul className="space-y-2">
              {recipe.extendedIngredients.map((ingredient) => (
                <li
                  key={ingredient.id}
                  className="p-3 rounded-lg bg-muted"
                >
                  {ingredient.original}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-semibold mb-4">Instructions</h2>
            <div className="prose prose-neutral dark:prose-invert max-w-none">
              {recipe.instructions.split('\n').map((step, index) => (
                <p key={index}>{step}</p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}