export default function About() {
  return (
    <main className="min-h-[calc(100vh-4rem)] bg-background">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-6">About Recipe Finder</h1>
          
          <div className="prose prose-neutral dark:prose-invert max-w-none">
            <p className="text-lg mb-6">
              Recipe Finder is your ultimate companion in the kitchen, helping you discover delicious recipes
              based on the ingredients you have, the cuisine you love, or simply what you're craving.
            </p>

            <h2 className="text-2xl font-semibold mt-8 mb-4">Our Mission</h2>
            <p>
              We believe that cooking should be accessible, enjoyable, and waste-free. Our platform helps you:
            </p>
            <ul>
              <li>Find recipes that match your available ingredients</li>
              <li>Discover new cuisines and cooking techniques</li>
              <li>Save your favorite recipes for quick access</li>
              <li>Make the most of your ingredients and reduce food waste</li>
            </ul>

            <h2 className="text-2xl font-semibold mt-8 mb-4">How It Works</h2>
            <p>
              Simply enter ingredients, cuisine types, or keywords in the search bar. Our intelligent
              recipe search will help you find the perfect dish. Save your favorites to build your
              personal cookbook, and access detailed instructions and ingredient lists whenever you need them.
            </p>

            <h2 className="text-2xl font-semibold mt-8 mb-4">Data Sources</h2>
            <p>
              Recipe Finder uses the Spoonacular API to provide you with accurate, detailed recipe
              information. Our database includes thousands of recipes from various cuisines and dietary
              preferences.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}