// Local storage key for favorites
const FAVORITES_KEY = 'recipe-finder-favorites';

export type FavoriteRecipe = {
  id: number;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  healthScore: number;
};

// Get favorites from local storage
export function getFavorites(): FavoriteRecipe[] {
  if (typeof window === 'undefined') return [];
  
  const favorites = localStorage.getItem(FAVORITES_KEY);
  return favorites ? JSON.parse(favorites) : [];
}

// Add a recipe to favorites
export function addToFavorites(recipe: FavoriteRecipe): void {
  const favorites = getFavorites();
  if (!favorites.some(fav => fav.id === recipe.id)) {
    favorites.push(recipe);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  }
}

// Remove a recipe from favorites
export function removeFromFavorites(recipeId: number): void {
  const favorites = getFavorites();
  const updatedFavorites = favorites.filter(recipe => recipe.id !== recipeId);
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(updatedFavorites));
}

// Check if a recipe is in favorites
export function isInFavorites(recipeId: number): boolean {
  const favorites = getFavorites();
  return favorites.some(recipe => recipe.id === recipeId);
}